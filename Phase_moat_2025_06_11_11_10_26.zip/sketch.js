let sun, clouds = [], trees = [], animals = [];
let fieldColor, windStrength = 0.5;
let particles = [];

function setup() {
    createCanvas(windowWidth, windowHeight);
    fieldColor = color(34, 139, 34);  // Verde para o campo

    // Criando o Sol
    sun = new Sun(width / 2, height / 4);

    // Criando nuvens
    for (let i = 0; i < 5; i++) {
        clouds.push(new Cloud(random(width), random(50, 150)));
    }

    // Criando árvores
    for (let i = 0; i < 5; i++) {
        trees.push(new Tree(random(width), height - 100));
    }

    // Criando animais (cavalos, vacas, etc)
    for (let i = 0; i < 3; i++) {
        animals.push(new Animal(random(width), height - 150));
    }

    // Criando partículas de grama
    for (let i = 0; i < 200; i++) {
        particles.push(new Particle(random(width), height / 2 + random(50, 100)));
    }
}

function draw() {
    background(135, 206, 235);  // Céu azul claro

    // Desenhando o campo
    fill(fieldColor);
    noStroke();
    rect(0, height / 2, width, height / 2);  // Grama

    // Desenhando partículas de grama
    for (let p of particles) {
        p.update();
        p.display();
    }

    // Movendo e desenhando o sol
    sun.move();
    sun.display();

    // Movendo e desenhando as nuvens
    for (let cloud of clouds) {
        cloud.move();
        cloud.display();
    }

    // Desenhando as árvores
    for (let tree of trees) {
        tree.display();
    }

    // Desenhando os animais
    for (let animal of animals) {
        animal.move();
        animal.display();
    }

    // Adicionando efeito de vento
    applyWindEffect();
}

// Classe do sol
class Sun {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 60;
        this.speed = 0.5;
    }

    display() {
        fill(255, 223, 0);
        noStroke();
        ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    }

    move() {
        this.y += sin(frameCount * 0.01) * this.speed;
    }
}

// Classe para nuvens
class Cloud {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = random(50, 100);
        this.speed = random(0.2, 0.5);
    }

    move() {
        this.x += this.speed;
        if (this.x > width + this.size) {
            this.x = -this.size;
        }
    }

    display() {
        fill(255, 255, 255, 200);
        noStroke();
        ellipse(this.x, this.y, this.size, this.size * 0.6);
        ellipse(this.x - this.size / 3, this.y, this.size, this.size * 0.6);
        ellipse(this.x + this.size / 3, this.y, this.size, this.size * 0.6);
    }
}

// Classe para as árvores
class Tree {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.trunkWidth = 30;
        this.trunkHeight = 60;
        this.foliageSize = 100;
    }

    display() {
        fill(139, 69, 19);  // Tronco
        noStroke();
        rect(this.x - this.trunkWidth / 2, this.y - this.trunkHeight, this.trunkWidth, this.trunkHeight);

        fill(34, 139, 34);  // Foliagem
        ellipse(this.x, this.y - this.trunkHeight - this.foliageSize / 2, this.foliageSize, this.foliageSize);
    }
}

// Classe para animais (ex: vaca, cavalo)
class Animal {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 50;
        this.speed = random(0.5, 1);
        this.direction = random(0, 1) > 0.5 ? 1 : -1;
    }

    move() {
        this.x += this.speed * this.direction;
        if (this.x > width || this.x < 0) {
            this.direction *= -1;
        }
    }

    display() {
        fill(255, 255, 255);
        noStroke();
        ellipse(this.x, this.y, this.size, this.size / 1.5);  // Corpo do animal

        fill(0);
        ellipse(this.x - 10, this.y - 10, 10, 10);  // Olho
    }
}

// Classe para partículas (efeito de grama)
class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = random(3, 6);
        this.alpha = random(100, 255);
        this.speed = random(0.5, 1);
    }

    update() {
        this.y += this.speed;
        if (this.y > height) {
            this.y = height / 2 + random(50, 100);
            this.alpha = random(100, 255);
        }
    }

    display() {
        fill(34, 139, 34, this.alpha);
        noStroke();
        ellipse(this.x, this.y, this.size, this.size);
    }
}

// Função que aplica o efeito de vento
function applyWindEffect() {
    for (let tree of trees) {
        let windEffect = sin(frameCount * windStrength) * 5;
        tree.foliageSize += windEffect;
    }
}

function mousePressed() {
    // Ao clicar, muda a cor do campo
    fieldColor = color(random(100, 150), random(150, 200), random(30, 90));
}
